package com.example.panels;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Cursor;
//import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

// Import the panel classes correctly
import com.example.panels.HomePanel;
import com.example.panels.ManageSuppliersPanel;
import com.example.panels.ManageInventoryPanel;
import com.example.panels.ManageEmployeesPanel;
import com.example.panels.MonthlyReportsPanel;
import com.example.panels.Customer;

public class HomeTechRepair extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JPanel mainContentPanel;
    private CardLayout cardLayout;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                HomeTechRepair frame = new HomeTechRepair();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public HomeTechRepair() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1000, 600);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Side panel for labels
        JPanel sidePanel = new JPanel();
        sidePanel.setBackground(Color.decode("#222f3e"));
        sidePanel.setBounds(0, 0, 220, 563); // Side panel width
        contentPane.add(sidePanel);
        sidePanel.setLayout(null);

        // Logo (Placeholder for image)
        JLabel lblLogo = new JLabel();
        lblLogo.setBounds(60, 20, 90, 90);
        ImageIcon originalIcon = new ImageIcon(getClass().getResource("/Images/maintenance.png"));
        Image scaledImage = originalIcon.getImage().getScaledInstance(90, 90, Image.SCALE_SMOOTH);
        lblLogo.setIcon(new ImageIcon(scaledImage));
        sidePanel.add(lblLogo);

        // TechRepair Title Label
        JLabel lblTitle = new JLabel("Tech Repair");
        lblTitle.setFont(new Font("Comic Sans MS", Font.BOLD, 20));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setBounds(40, 110, 180, 50); // Adjusted position
        sidePanel.add(lblTitle);

        // Menu items with icons
        String[] menuItems = {
            "Home", "Customers", "Manage Suppliers", "Manage Inventory",
            "Manage Employees", "Monthly Reports"
        };
        String[] iconPaths = {
            "/Images/home.png", "/Images/customers.png", "/Images/suppliers.png", 
            "/Images/inventory.png", "/Images/employees.png", 
            "/Images/reports.png"
        };

        int startY = 165;
        int labelHeight = 55; // Ensure labels fill the height evenly

        for (int i = 0; i < menuItems.length; i++) {
            final String menuItem = menuItems[i];
            
            // Load icon for the menu item
            ImageIcon icon = new ImageIcon(getClass().getResource(iconPaths[i]));
            Image img = icon.getImage().getScaledInstance(24, 24, Image.SCALE_SMOOTH);
            icon = new ImageIcon(img);

            JLabel menuLabel = new JLabel(menuItem);
            menuLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
            menuLabel.setHorizontalAlignment(SwingConstants.LEFT); // Left align the text
            menuLabel.setBounds(30, startY + (i * labelHeight), 180, labelHeight);
            menuLabel.setIcon(icon); // Set the icon
            menuLabel.setIconTextGap(10); // Space between icon and text
            menuLabel.setOpaque(false); // Make background transparent
            menuLabel.setForeground(Color.WHITE);
            menuLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));

            // Only keep the mouseClicked event
            menuLabel.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    cardLayout.show(mainContentPanel, menuItem);
                }
            });

            sidePanel.add(menuLabel);
        }


        // Main content panel with CardLayout
        mainContentPanel = new JPanel();
        cardLayout = new CardLayout();
        mainContentPanel.setLayout(cardLayout);
        mainContentPanel.setBounds(220, 0, 780, 563); // Right side of the frame
        contentPane.add(mainContentPanel);

        // Initialize panels
        HomePanel homePanel = new HomePanel();
      
        ManageSuppliersPanel manageSuppliersPanel = new ManageSuppliersPanel(sidePanel, cardLayout);
        ManageInventoryPanel manageInventoryPanel = new ManageInventoryPanel(sidePanel, cardLayout);
        ManageEmployeesPanel manageEmployeesPanel = new ManageEmployeesPanel(sidePanel, cardLayout);
        MonthlyReportsPanel monthlyReportsPanel = new MonthlyReportsPanel();
        Customer customerPanel = new Customer(sidePanel, cardLayout);

        // Add different content panels to the main content panel
        mainContentPanel.add(homePanel, "Home");
      
        mainContentPanel.add(manageSuppliersPanel, "Manage Suppliers");
        mainContentPanel.add(manageInventoryPanel, "Manage Inventory");
        mainContentPanel.add(manageEmployeesPanel, "Manage Employees");
        mainContentPanel.add(monthlyReportsPanel, "Monthly Reports");
        mainContentPanel.add(customerPanel, "Customers");

        // Initially show the home panel
        cardLayout.show(mainContentPanel, "Home");
        setLocationRelativeTo(null);
        setResizable(false);
    }
}
