package com.example.panels;

import javax.swing.*;
import java.awt.*;

public class HomePanel extends JPanel {

    private Image backgroundImage;

    // Constructor to load the background image
    public HomePanel() {
        // Load the background image using ClassLoader
        try {
            backgroundImage = new ImageIcon(getClass().getClassLoader().getResource("Images/background.png")).getImage();
        } catch (Exception e) {
            System.out.println("Image not found: " + e.getMessage());
        }
        
        // Set panel size dynamically based on parent container's size
        setPreferredSize(new Dimension(Toolkit.getDefaultToolkit().getScreenSize()));
    }

    // Override the paintComponent method to draw the background image
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Draw the background image, scaling it to fit the panel size
        if (backgroundImage != null) {
            // Automatically scale the image to the current size of the panel
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }
    }
}
