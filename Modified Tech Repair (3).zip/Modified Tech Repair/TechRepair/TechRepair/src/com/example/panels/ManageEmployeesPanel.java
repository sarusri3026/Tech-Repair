package com.example.panels;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ManageEmployeesPanel extends JPanel {
    private CardLayout cardLayout;
    private JPanel mainPanel;
    private JTextField textField, textField_1, textField_2, textField_3, textField_5;
    private JComboBox<String> comboBox, comboBox_1, comboBox_2;
    private JButton btnAdd, btnUpdate, btnRemove;

    public ManageEmployeesPanel(JPanel mainPanel, CardLayout cardLayout) {
        this.mainPanel = mainPanel;
        this.cardLayout = cardLayout;

        setBackground(Color.WHITE);
        setLayout(null);

        // Initialize components and layout
        initComponents();

        // Add ActionListeners
        addEventListeners();
    }

    // Method to initialize components
    private void initComponents() {
        JLabel lblTitle = new JLabel("Employees - TECHREPAIR");
        lblTitle.setFont(new Font("Tempus Sans ITC", Font.BOLD, 28));
        lblTitle.setForeground(new Color(45, 52, 54));
        lblTitle.setBounds(10, 0, 711, 43);
        add(lblTitle);

        // Labels
        addLabel("Employee ID :", 99, 65);
        addLabel("Full name :", 99, 118);
        addLabel("Address :", 99, 193);
        addLabel("Contact Number :", 99, 250);
        addLabel("Email :", 99, 303);
        addLabel("Employee Role :", 99, 355);
        addLabel("Employee Schedule :", 99, 417);
        addLabel("Employee Status:", 99, 468);

        // Text fields
        textField_5 = createTextField(252, 68, 123);
        textField = createTextField(252, 121, 342);
        textField_1 = createTextField(252, 180, 342);
        textField_2 = createTextField(252, 253, 342);
        textField_3 = createTextField(252, 306, 342);

        // Combo boxes
        comboBox_2 = createComboBox(new String[]{
            "Technician", "Customer Support Specialist", "Store Manager", "Inventory Manager",
            "Repair Specialist", "Quality Control Inspector", "Sales Representative",
            "Accounts Manager", "Logistics Coordinator", "IT Support Specialist"}, 252, 357, 342);

        comboBox = createComboBox(new String[]{
            "Order Confirmed", "Order Processing", "On the way to warehouse", "Purchased", "Returned"}, 252, 419, 342);

        comboBox_1 = createComboBox(new String[]{"Active", "Inactive"}, 252, 470, 342);

        // Buttons
        btnAdd = createButton("Add", Color.GREEN, 620, 522);
        btnUpdate = createButton("Update", Color.BLUE, 500, 522);
        btnRemove = createButton("Remove", Color.RED, 377, 522);
    }

    // Utility methods to create components
    private void addLabel(String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Franklin Gothic Book", Font.PLAIN, 17));
        label.setBounds(x, y, 200, 29);
        add(label);
    }

    private JTextField createTextField(int x, int y, int width) {
        JTextField textField = new JTextField();
        textField.setBounds(x, y, width, 26);
        add(textField);
        return textField;
    }

    private JComboBox<String> createComboBox(String[] items, int x, int y, int width) {
        JComboBox<String> comboBox = new JComboBox<>(items);
        comboBox.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 15));
        comboBox.setBounds(x, y, width, 27);
        add(comboBox);
        return comboBox;
    }

    private JButton createButton(String text, Color color, int x, int y) {
        JButton button = new JButton(text);
        button.setFont(new Font("Tahoma", Font.BOLD, 13));
        button.setForeground(Color.WHITE);
        button.setBackground(color);
        button.setBounds(x, y, 110, 29);
        add(button);
        return button;
    }

    // Adding action listeners for buttons and employee ID text field
    private void addEventListeners() {
        btnAdd.addActionListener(e -> {
            addEmployee();
            clearFields();
        });

        btnUpdate.addActionListener(e -> {
            updateEmployee();
            clearFields();
        });

        btnRemove.addActionListener(e -> {
            removeEmployee();
            clearFields();
        });

        // Document listener to load employee details when ID is entered
        textField_5.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { loadEmployeeIfNotEmpty(); }
            @Override
            public void removeUpdate(DocumentEvent e) { loadEmployeeIfNotEmpty(); }
            @Override
            public void changedUpdate(DocumentEvent e) { loadEmployeeIfNotEmpty(); }
        });
    }

    private void loadEmployeeIfNotEmpty() {
        String employeeId = textField_5.getText();
        if (!employeeId.isEmpty()) {
            loadEmployeeDetails(employeeId);
        } else {
            clearFields();
        }
    }

    private void addEmployee() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "INSERT INTO Employees (employee_id, name, address, contact_no, email, employee_role, employee_schedule, employee_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                setEmployeeParams(pstmt);
                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Employee added successfully.");
            }
        } catch (SQLException e) {
            handleError(e, "Error adding employee.");
        }
    }

    private void updateEmployee() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "UPDATE Employees SET name = ?, address = ?, contact_no = ?, email = ?, employee_role = ?, employee_schedule = ?, employee_status = ? WHERE employee_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                setEmployeeParams(pstmt);
                pstmt.setInt(8, Integer.parseInt(textField_5.getText()));
                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Employee updated successfully.");
            }
        } catch (SQLException e) {
            handleError(e, "Error updating employee.");
        }
    }

    private void removeEmployee() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "DELETE FROM Employees WHERE employee_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, Integer.parseInt(textField_5.getText()));
                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Employee removed successfully.");
            }
        } catch (SQLException e) {
            handleError(e, "Error removing employee.");
        }
    }

    private void loadEmployeeDetails(String employeeId) {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM Employees WHERE employee_id = ?")) {

            pstmt.setString(1, employeeId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    textField.setText(rs.getString("name"));
                    textField_1.setText(rs.getString("address"));
                    textField_2.setText(rs.getString("contact_no"));
                    textField_3.setText(rs.getString("email"));
                    comboBox_2.setSelectedItem(rs.getString("employee_role"));
                    comboBox.setSelectedItem(rs.getString("employee_schedule"));
                    comboBox_1.setSelectedItem(rs.getString("employee_status"));
                }
            }
        } catch (SQLException e) {
            handleError(e, "Error loading employee details.");
        }
    }

    private void setEmployeeParams(PreparedStatement pstmt) throws SQLException {
        pstmt.setInt(1, Integer.parseInt(textField_5.getText()));
        pstmt.setString(2, textField.getText());
        pstmt.setString(3, textField_1.getText());
        pstmt.setString(4, textField_2.getText());
        pstmt.setString(5, textField_3.getText());
        pstmt.setString(6, (String) comboBox_2.getSelectedItem());
        pstmt.setString(7, (String) comboBox.getSelectedItem());
        pstmt.setString(8, (String) comboBox_1.getSelectedItem());
    }

    // Error handling method
    private void handleError(Exception e, String message) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, message);
    }

    // Method to clear all text fields and combo boxes
    private void clearFields() {
        textField_5.setText("");
        textField.setText("");
        textField_1.setText("");
        textField_2.setText("");
        textField_3.setText("");
        comboBox_2.setSelectedIndex(0);
        comboBox.setSelectedIndex(0);
        comboBox_1.setSelectedIndex(0);
    }
}
