package com.example.panels;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ManageSuppliersPanel extends JPanel {

    private CardLayout cardLayout;
    private JPanel mainPanel;
    private JTextField textField;  // Full name
    private JTextField textField_1;  // Address
    private JTextField textField_2;  // Contact Number
    private JTextField textField_3;  // Email
    private JTextField textField_4;  // Supplies Details
    private JTextField textField_5;  // Supplier ID
    private JComboBox<String> comboBox;  // Supplies Status
    private JComboBox<String> comboBox_1;  // Supplier Status
    private JButton btnRemove;
    private JButton btnUpdate;
    private JButton btnAdd;
    private JLabel lblSupplierId;

    public ManageSuppliersPanel(JPanel mainPanel, CardLayout cardLayout) {
        this.mainPanel = mainPanel;
        this.cardLayout = cardLayout;
        setBackground(Color.WHITE);
        setLayout(null);

        // Initialize components
        initComponents();

        // Add Action Listeners
        btnAdd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validateFields()) {
                    addSupplier();
                    clearTextFields(); // Clear fields after adding supplier
                }
            }
        });

        btnUpdate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validateFields() && !textField_5.getText().isEmpty()) {
                    updateSupplier();
                    clearTextFields(); // Clear fields after updating supplier
                } else {
                    JOptionPane.showMessageDialog(ManageSuppliersPanel.this, "Please enter a Supplier ID to update.");
                }
            }
        });

        btnRemove.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!textField_5.getText().isEmpty()) {
                    removeSupplier();
                    clearTextFields(); // Clear fields after removing supplier
                } else {
                    JOptionPane.showMessageDialog(ManageSuppliersPanel.this, "Please enter a Supplier ID to remove.");
                }
            }
        });

    }

    private void initComponents() {
        JLabel lblFullName = new JLabel("Full name:");
        lblFullName.setFont(new Font("Franklin Gothic Book", Font.PLAIN, 17));
        lblFullName.setBounds(99, 94, 123, 29);
        add(lblFullName);

        textField = new JTextField();
        textField.setBounds(252, 97, 342, 26);
        add(textField);
        textField.setColumns(10);

        JLabel lblAddress = new JLabel("Address:");
        lblAddress.setFont(new Font("Franklin Gothic Book", Font.PLAIN, 17));
        lblAddress.setBounds(99, 158, 123, 29);
        add(lblAddress);

        textField_1 = new JTextField();
        textField_1.setBounds(252, 145, 342, 58);
        add(textField_1);
        textField_1.setColumns(10);

        JLabel lblContactNumber = new JLabel("Contact Number:");
        lblContactNumber.setFont(new Font("Franklin Gothic Book", Font.PLAIN, 17));
        lblContactNumber.setBounds(99, 226, 143, 29);
        add(lblContactNumber);

        textField_2 = new JTextField();
        textField_2.setBounds(252, 226, 342, 26);
        add(textField_2);
        textField_2.setColumns(10);

        JLabel lblEmail = new JLabel("Email:");
        lblEmail.setFont(new Font("Franklin Gothic Book", Font.PLAIN, 17));
        lblEmail.setBounds(99, 266, 123, 29);
        add(lblEmail);

        textField_3 = new JTextField();
        textField_3.setBounds(252, 269, 342, 26);
        add(textField_3);
        textField_3.setColumns(10);

        JLabel lblSuppliesDetails = new JLabel("Order ID");
        lblSuppliesDetails.setFont(new Font("Franklin Gothic Book", Font.PLAIN, 17));
        lblSuppliesDetails.setBounds(99, 341, 143, 29);
        add(lblSuppliesDetails);

        textField_4 = new JTextField();
        textField_4.setBounds(252, 320, 342, 36);
        add(textField_4);
        textField_4.setColumns(10);

        JLabel lblSuppliesStatus = new JLabel("Supplies Status:");
        lblSuppliesStatus.setFont(new Font("Franklin Gothic Book", Font.PLAIN, 17));
        lblSuppliesStatus.setBounds(99, 417, 123, 29);
        add(lblSuppliesStatus);

        comboBox = new JComboBox<>();
        comboBox.setModel(new DefaultComboBoxModel<>(new String[]{"Order Confirmed", "Order Processing", "On the way to warehouse", "Purchased", "Returned"}));
        comboBox.setBounds(252, 419, 342, 27);
        add(comboBox);

        JLabel lblSupplierStatus = new JLabel("Supplier Status:");
        lblSupplierStatus.setFont(new Font("Franklin Gothic Book", Font.PLAIN, 17));
        lblSupplierStatus.setBounds(99, 468, 143, 29);
        add(lblSupplierStatus);

        comboBox_1 = new JComboBox<>();
        comboBox_1.setModel(new DefaultComboBoxModel<>(new String[]{"Active", "Inactive"}));
        comboBox_1.setBounds(252, 470, 342, 27);
        add(comboBox_1);

        lblSupplierId = new JLabel("Supplier ID:");
        lblSupplierId.setFont(new Font("Franklin Gothic Book", Font.PLAIN, 17));
        lblSupplierId.setBounds(99, 54, 123, 29);
        add(lblSupplierId);

        textField_5 = new JTextField();
        textField_5.setBounds(252, 60, 123, 26);
        add(textField_5);
        textField_5.setColumns(10);

        btnRemove = new JButton("Remove");
        btnRemove.setFont(new Font("Tahoma", Font.BOLD, 13));
        btnRemove.setForeground(Color.WHITE);
        btnRemove.setBackground(Color.RED);
        btnRemove.setBounds(377, 522, 110, 29);
        add(btnRemove);

        btnUpdate = new JButton("Update");
        btnUpdate.setFont(new Font("Tahoma", Font.BOLD, 13));
        btnUpdate.setForeground(Color.WHITE);
        btnUpdate.setBackground(Color.BLUE);
        btnUpdate.setBounds(500, 522, 110, 29);
        add(btnUpdate);

        btnAdd = new JButton("Add");
        btnAdd.setFont(new Font("Tahoma", Font.BOLD, 13));
        btnAdd.setForeground(Color.WHITE);
        btnAdd.setBackground(Color.GREEN);
        btnAdd.setBounds(620, 522, 110, 29);
        add(btnAdd);

        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setBounds(0, 0, 800, 43);
        add(panel);
        panel.setLayout(null);

        JLabel lblTitle = new JLabel("Suppliers - TECHREPAIR");
        lblTitle.setFont(new Font("Tempus Sans ITC", Font.BOLD, 28));
        lblTitle.setForeground(new Color(45, 52, 54));
        lblTitle.setBounds(10, 0, 711, 43);
        panel.add(lblTitle);
    }

   private void addSupplier() {
    String ID = textField_5.getText();
    String name = textField.getText();
    String address = textField_1.getText();
    String contactNo = textField_2.getText();
    String email = textField_3.getText();
    String ItemID = textField_4.getText();
    String suppliesStatus = (String) comboBox.getSelectedItem();
    String supplierStatus = (String) comboBox_1.getSelectedItem();

    // Corrected the SQL statement by adding a placeholder for all 8 columns
    String sql = "INSERT INTO suppliers (supplier_id, name, address, contact_no, email, item_id, supplies_status, supplier_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setString(1, ID); // Supplier ID
        pstmt.setString(2, name);
        pstmt.setString(3, address);
        pstmt.setString(4, contactNo);
        pstmt.setString(5, email);
        pstmt.setString(6, ItemID);
        pstmt.setString(7, suppliesStatus);
        pstmt.setString(8, supplierStatus);

        pstmt.executeUpdate();
        JOptionPane.showMessageDialog(this, "Supplier added successfully.");
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error adding supplier.");
    }
}

    
    private void updateSupplier() {
        try {
            int supplierId = Integer.parseInt(textField_5.getText());
            String name = textField.getText();
            String address = textField_1.getText();
            String contactNo = textField_2.getText();
            String email = textField_3.getText();
            String suppliesDetails = textField_4.getText();
            String suppliesStatus = (String) comboBox.getSelectedItem();
            String supplierStatus = (String) comboBox_1.getSelectedItem();

            String sql = "UPDATE suppliers SET name = ?, address = ?, contact_no = ?, email = ?, supplies_details = ?, item_id = ?, supplier_status = ? WHERE supplier_id = ?";

            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, name);
                pstmt.setString(2, address);
                pstmt.setString(3, contactNo);
                pstmt.setString(4, email);
                pstmt.setString(5, suppliesDetails);
                pstmt.setString(6, suppliesStatus);
                pstmt.setString(7, supplierStatus);
                pstmt.setInt(8, supplierId);

                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Supplier updated successfully.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid Supplier ID format.");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating supplier.");
        }
    }

    private void removeSupplier() {
        try {
            int supplierId = Integer.parseInt(textField_5.getText());

            String sql = "DELETE FROM uppliers WHERE supplier_id = ?";

            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, supplierId);

                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Supplier removed successfully.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid Supplier ID format.");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error removing supplier.");
        }
    }

//    private void loadSupplierData(String id) {
//    	String sql = "SELECT * FROM Suppliers WHERE supplier_id = ?";
//        try {
//            String text = textField_5.getText();
//            if (text.isEmpty()) {
//                clearTextFields();
//                return;
//            }
//
//            int supplierId = Integer.parseInt(text);
//
//
//            try (Connection conn = DatabaseConnection.getConnection();
//                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
//                pstmt.setInt(1, supplierId);
//                ResultSet rs = pstmt.executeQuery();
//
//                if (rs.next()) {
//                    textField.setText(rs.getString("name"));
//                    textField_1.setText(rs.getString("address"));
//                    textField_2.setText(rs.getString("contact_no"));
//                    textField_3.setText(rs.getString("email"));
//                    textField_4.setText(rs.getString("supplies_details"));
//                    comboBox.setSelectedItem(rs.getString("supplies_status"));
//                    comboBox_1.setSelectedItem(rs.getString("supplier_status"));
//                } else {
//                    JOptionPane.showMessageDialog(this, "Supplier ID not found.");
//                    clearTextFields();
//                }
//            }
//        } catch (NumberFormatException e) {
//            JOptionPane.showMessageDialog(this, "Invalid Supplier ID format.");
//        } catch (SQLException e) {
//            e.printStackTrace();
//            JOptionPane.showMessageDialog(this, "Error loading supplier data.");
//        }
//    }

    private boolean validateFields() {
        if (textField.getText().isEmpty() || textField_1.getText().isEmpty() || textField_2.getText().isEmpty() || textField_3.getText().isEmpty() || textField_4.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.");
            return false;
        }
        return true;
    }

    private void clearTextFields() {
        textField.setText("");
        textField_1.setText("");
        textField_2.setText("");
        textField_3.setText("");
        textField_4.setText("");
        textField_5.setText("");
        comboBox.setSelectedIndex(0);
        comboBox_1.setSelectedIndex(0);
    }
}
