package com.example.panels;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Customer extends JPanel {
    private CardLayout cardLayout;
    private JPanel mainPanel;
    private JTextField textField;
    private JTextField textField_1;
    private JTextField textField_2;
    private JTextField textField_3;
    private JComboBox<String> comboBox_1;
    private JTextField textField_5;

    public Customer(JPanel mainPanel, CardLayout cardLayout) {
        setBackground(Color.WHITE);
        setLayout(null);
        
        // Labels and Text Fields
        JLabel lblNewLabel = new JLabel("Full name :");
        lblNewLabel.setFont(new Font("Franklin Gothic Book", Font.PLAIN, 17));
        lblNewLabel.setBounds(99, 124, 123, 29);
        add(lblNewLabel);
        
        textField = new JTextField();
        textField.setBounds(252, 127, 342, 26);
        add(textField);
        textField.setColumns(10);
        
        JLabel lblNewLabel_1 = new JLabel("Address :");
        lblNewLabel_1.setFont(new Font("Franklin Gothic Book", Font.PLAIN, 17));
        lblNewLabel_1.setBounds(99, 197, 123, 29);
        add(lblNewLabel_1);
        
        textField_1 = new JTextField();
        textField_1.setColumns(10);
        textField_1.setBounds(252, 184, 342, 58);
        add(textField_1);
        
        JLabel lblNewLabel_2 = new JLabel("Contact Number :");
        lblNewLabel_2.setFont(new Font("Franklin Gothic Book", Font.PLAIN, 17));
        lblNewLabel_2.setBounds(99, 281, 143, 29);
        add(lblNewLabel_2);
        
        textField_2 = new JTextField();
        textField_2.setColumns(10);
        textField_2.setBounds(252, 284, 342, 26);
        add(textField_2);
        
        JLabel lblNewLabel_3 = new JLabel("Email :");
        lblNewLabel_3.setFont(new Font("Franklin Gothic Book", Font.PLAIN, 17));
        lblNewLabel_3.setBounds(99, 352, 123, 29);
        add(lblNewLabel_3);
        
        textField_3 = new JTextField();
        textField_3.setColumns(10);
        textField_3.setBounds(252, 355, 342, 26);
        add(textField_3);
        
        JLabel lblNewLabel_6 = new JLabel("Customer Status:");
        lblNewLabel_6.setFont(new Font("Franklin Gothic Book", Font.PLAIN, 17));
        lblNewLabel_6.setBounds(99, 423, 143, 29);
        add(lblNewLabel_6);
        
        comboBox_1 = new JComboBox<>();
        comboBox_1.setModel(new DefaultComboBoxModel<>(new String[]{"Active", "Inactive"}));
        comboBox_1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 15));
        comboBox_1.setBounds(252, 425, 342, 27);
        add(comboBox_1);
        
        JLabel lblCustomerId = new JLabel("Customer ID :");
        lblCustomerId.setFont(new Font("Franklin Gothic Book", Font.PLAIN, 17));
        lblCustomerId.setBounds(99, 73, 123, 29);
        add(lblCustomerId);
        
        textField_5 = new JTextField();
        textField_5.setColumns(10);
        textField_5.setBounds(252, 76, 123, 26);
        add(textField_5);
        
        // Buttons
        JButton btnNewButton_2 = new JButton("Add");
        btnNewButton_2.setForeground(Color.WHITE);
        btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 13));
        btnNewButton_2.setBackground(Color.GREEN);
        btnNewButton_2.setBounds(620, 522, 110, 29);
        add(btnNewButton_2);
        
        JButton btnUpdate = new JButton("Update");
        btnUpdate.setForeground(Color.WHITE);
        btnUpdate.setFont(new Font("Tahoma", Font.BOLD, 13));
        btnUpdate.setBackground(new Color(0, 102, 255));
        btnUpdate.setBounds(500, 522, 110, 29);
        add(btnUpdate);
        
        JButton btnNewButton = new JButton("Remove");
        btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 13));
        btnNewButton.setForeground(Color.WHITE);
        btnNewButton.setBackground(new Color(255, 0, 51));
        btnNewButton.setBounds(377, 522, 110, 29);
        add(btnNewButton);
        
        JPanel panel = new JPanel();
        panel.setForeground(new Color(255, 255, 255));
        panel.setBackground(Color.WHITE);
        panel.setBounds(0, 0, 800, 43);
        add(panel);
        panel.setLayout(null);
        
        JLabel lblNewLabel_7 = new JLabel("Customers - TECHREPAIR");
        lblNewLabel_7.setFont(new Font("Tempus Sans ITC", Font.BOLD, 28));
        lblNewLabel_7.setForeground(new Color(45, 52, 54));
        lblNewLabel_7.setBounds(10, 0, 711, 43);
        panel.add(lblNewLabel_7);

        // Button Actions
        btnNewButton_2.addActionListener(e -> {
            String customerId = textField_5.getText();
            String fullName = textField.getText();
            String address = textField_1.getText();
            String contactNo = textField_2.getText();
            String email = textField_3.getText();
            String status = comboBox_1.getSelectedItem().toString();
            addCustomer(customerId, fullName, address, contactNo, email, status);
            clearTextFields(); // Clear fields after adding customer
        });

        btnUpdate.addActionListener(e -> {
            String customerId = textField_5.getText();
            String fullName = textField.getText();
            String address = textField_1.getText();
            String contactNo = textField_2.getText();
            String email = textField_3.getText();
            String status = comboBox_1.getSelectedItem().toString();
            updateCustomer(customerId, fullName, address, contactNo, email, status);
            clearTextFields(); // Clear fields after updating customer
        });

        btnNewButton.addActionListener(e -> {
            String customerId = textField_5.getText();
            removeCustomer(customerId);
            clearTextFields(); // Clear fields after removing customer
        });

     
     // Add ActionListener to textField_5 for loading customer details
        textField_5.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                textChanged();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                textChanged();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                textChanged();
            }

            private void textChanged() {
                String customerId = textField_5.getText();
                if (!customerId.isEmpty()) {
                    loadCustomerDetails(customerId);  // Load customer details if ID is not empty
                } else {
                    clearTextFields();  // Clear fields if ID is empty
                }
            }
        });

        	
        }
          
    

    // Database Methods
    private void addCustomer(String customerId, String fullName, String address, String contactNo, String email, String status) {
        String query = "INSERT INTO Customers (customer_id, full_name, address, contact_no, email, customer_status) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setString(1, customerId);
            ps.setString(2, fullName);
            ps.setString(3, address);
            ps.setString(4, contactNo);
            ps.setString(5, email);
            ps.setString(6, status);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Customer added successfully!");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

    private void updateCustomer(String customerId, String fullName, String address, String contactNo, String email, String status) {
        String query = "UPDATE Customers SET full_name = ?, address = ?, contact_no = ?, email = ?, customer_status = ? WHERE customer_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setString(1, fullName);
            ps.setString(2, address);
            ps.setString(3, contactNo);
            ps.setString(4, email);
            ps.setString(5, status);
            ps.setString(6, customerId);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Customer updated successfully!");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

    private void removeCustomer(String customerId) {
        String query = "DELETE FROM Customers WHERE customer_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setString(1, customerId);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Customer removed successfully!");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

    private void loadCustomerDetails(String customerId) {
        String query = "SELECT * FROM Customers WHERE customer_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setString(1, customerId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    textField.setText(rs.getString("full_name"));
                    textField_1.setText(rs.getString("address"));
                    textField_2.setText(rs.getString("contact_no"));
                    textField_3.setText(rs.getString("email"));
                    comboBox_1.setSelectedItem(rs.getString("customer_status"));
                } 
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

    // Method to clear text fields
    private void clearTextFields() {
        textField.setText("");
        textField_1.setText("");
        textField_2.setText("");
        textField_3.setText("");
        textField_5.setText("");
        comboBox_1.setSelectedIndex(0); // Reset combo box to default value
    }
}
