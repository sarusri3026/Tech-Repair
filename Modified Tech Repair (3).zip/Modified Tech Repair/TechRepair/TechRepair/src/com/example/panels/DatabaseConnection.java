package com.example.panels;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/tech_repair?useSSL=false";
    private static final String USER = "root";
    private static final String PASSWORD = "";
    private static Connection conn;

    // Private constructor to prevent instantiation
    private DatabaseConnection() {
        try {
            // Use updated driver class
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException ex) {
            System.out.println("MySQL JDBC driver class not found. Include the MySQL Connector/J in your project.");
        } catch (SQLException ex) {
            System.out.println("Cannot connect to the database: " + ex.getMessage());
        }
    }

    // Static inner class for thread-safe Singleton pattern
    private static class SingletonHelper {
        private static final DatabaseConnection INSTANCE = new DatabaseConnection();
    }

    public static Connection getConnection() throws SQLException {
        if (conn == null || conn.isClosed()) {
            // Initialize the singleton instance
            new DatabaseConnection();
        }
        return conn;
    }
}
