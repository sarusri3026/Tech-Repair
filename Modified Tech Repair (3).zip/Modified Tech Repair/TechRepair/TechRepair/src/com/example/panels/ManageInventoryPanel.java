package com.example.panels;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class ManageInventoryPanel extends JPanel {

    private CardLayout cardLayout;
    private JPanel mainPanel;
    private JTextField textField;  // Item Name
    private JTextField textField_1;  // Supplier Name
    private JTextField textField_2;  // Purchased Price
    private JTextField textField_3;  // Selling Price
    private JTextField textField_5;  // Item ID
    private JComboBox<String> comboBoxStockStatus;
    private JButton btnAdd;
    private JButton btnUpdate;
    private JButton btnRemove;

    public ManageInventoryPanel(JPanel mainPanel, CardLayout cardLayout) {
        this.mainPanel = mainPanel;
        this.cardLayout = cardLayout;
        setBackground(Color.WHITE);
        setLayout(null);

        // Initialize components
        JLabel lblItemName = new JLabel("Item name:");
        lblItemName.setFont(new Font("Franklin Gothic Book", Font.PLAIN, 17));
        lblItemName.setBounds(99, 177, 123, 29);
        add(lblItemName);

        textField = new JTextField();
        textField.setBounds(252, 180, 342, 26);
        add(textField);
        textField.setColumns(10);

        JLabel lblSupplierName = new JLabel("Supplier name:");
        lblSupplierName.setFont(new Font("Franklin Gothic Book", Font.PLAIN, 17));
        lblSupplierName.setBounds(99, 236, 123, 29);
        add(lblSupplierName);

        textField_1 = new JTextField();
        textField_1.setColumns(10);
        textField_1.setBounds(252, 239, 342, 26);
        add(textField_1);

        JLabel lblPurchasedPrice = new JLabel("Purchased price:");
        lblPurchasedPrice.setFont(new Font("Franklin Gothic Book", Font.PLAIN, 17));
        lblPurchasedPrice.setBounds(99, 297, 143, 29);
        add(lblPurchasedPrice);

        textField_2 = new JTextField();
        textField_2.setColumns(10);
        textField_2.setBounds(252, 300, 342, 26);
        add(textField_2);

        JLabel lblSellingPrice = new JLabel("Selling price:");
        lblSellingPrice.setFont(new Font("Franklin Gothic Book", Font.PLAIN, 17));
        lblSellingPrice.setBounds(99, 364, 123, 29);
        add(lblSellingPrice);

        textField_3 = new JTextField();
        textField_3.setColumns(10);
        textField_3.setBounds(252, 367, 342, 26);
        add(textField_3);

        JLabel lblStockStatus = new JLabel("Stock status:");
        lblStockStatus.setFont(new Font("Franklin Gothic Book", Font.PLAIN, 17));
        lblStockStatus.setBounds(99, 428, 123, 29);
        add(lblStockStatus);

        comboBoxStockStatus = new JComboBox<>();
        comboBoxStockStatus.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 15));
        comboBoxStockStatus.setBounds(252, 430, 342, 27);
        comboBoxStockStatus.setModel(new DefaultComboBoxModel<>(new String[]{"In stock", "Out of stock"}));
        add(comboBoxStockStatus);

        JLabel lblItemId = new JLabel("Item ID:");
        lblItemId.setFont(new Font("Franklin Gothic Book", Font.PLAIN, 17));
        lblItemId.setBounds(99, 119, 123, 29);
        add(lblItemId);

        textField_5 = new JTextField();
        textField_5.setColumns(10);
        textField_5.setBounds(252, 122, 110, 26);
        add(textField_5);

        btnRemove = new JButton("Remove");
        btnRemove.setFont(new Font("Tahoma", Font.BOLD, 13));
        btnRemove.setForeground(Color.WHITE);
        btnRemove.setBackground(Color.RED);
        btnRemove.setBounds(377, 522, 110, 29);
        add(btnRemove);

        btnUpdate = new JButton("Update");
        btnUpdate.setForeground(Color.WHITE);
        btnUpdate.setFont(new Font("Tahoma", Font.BOLD, 13));
        btnUpdate.setBackground(Color.BLUE);
        btnUpdate.setBounds(500, 522, 110, 29);
        add(btnUpdate);

        btnAdd = new JButton("Add");
        btnAdd.setForeground(Color.WHITE);
        btnAdd.setFont(new Font("Tahoma", Font.BOLD, 13));
        btnAdd.setBackground(Color.GREEN);
        btnAdd.setBounds(620, 522, 110, 29);
        add(btnAdd);

        JPanel panel = new JPanel();
        panel.setForeground(Color.WHITE);
        panel.setBackground(Color.WHITE);
        panel.setBounds(0, 0, 800, 43);
        add(panel);
        panel.setLayout(null);

        JLabel lblTitle = new JLabel("Inventory - TECHREPAIR");
        lblTitle.setFont(new Font("Tempus Sans ITC", Font.BOLD, 28));
        lblTitle.setForeground(new Color(45, 52, 54));
        lblTitle.setBounds(10, 0, 711, 43);
        panel.add(lblTitle);

        // Add Action Listeners
        btnAdd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addItem();
            }
        });

        btnUpdate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateItem();
            }
        });

        btnRemove.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                removeItem();
            }
        });

//        textField_5.getDocument().addDocumentListener(new DocumentListener() {
//            @Override
//            public void insertUpdate(DocumentEvent e) {
//                textChanged();
//            }
//
//            @Override
//            public void removeUpdate(DocumentEvent e) {
//                textChanged();
//            }
//
//            @Override
//            public void changedUpdate(DocumentEvent e) {
//                textChanged();
//            }
//
//            private void textChanged() {
//                String InventoryID = textField_5.getText();
//                if (!InventoryID.isEmpty()) {
//                	loadItemData(InventoryID);  // Load customer details if ID is not empty
//                } else {
//                	clearFields();  // Clear fields if ID is empty
//                }
//            }
//        });

        	
        
    }

      private void addItem() {
        try {
            int itemId = Integer.parseInt(textField_5.getText());
            String itemName = textField.getText();
            String supplierName = (String) textField_1.getText();
            double purchasedPrice = Double.parseDouble(textField_2.getText());
            double sellingPrice = Double.parseDouble(textField_3.getText());
            String stockStatus = (String) comboBoxStockStatus.getSelectedItem();

            String sql = "INSERT INTO Inventory (item_id, item_name, supplier_name, purchased_price, selling_price, stock_status) VALUES (?, ?, ?, ?, ?, ?)";

            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, itemId);
                pstmt.setString(2, itemName);
                pstmt.setString(3, supplierName);
                pstmt.setDouble(4, purchasedPrice);
                pstmt.setDouble(5, sellingPrice);
                pstmt.setString(6, stockStatus);

                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Item added successfully.");
                clearFields();
            }
        } catch (NumberFormatException | SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error adding item. Ensure all fields are correctly filled.");
        }
    }
    private void updateItem() {
        try {
            int itemId = Integer.parseInt(textField_5.getText());
            String itemName = textField.getText();
            String supplierName = textField_1.getText();
            double purchasedPrice = Double.parseDouble(textField_2.getText());
            double sellingPrice = Double.parseDouble(textField_3.getText());
            String stockStatus = (String) comboBoxStockStatus.getSelectedItem();

            String sql = "UPDATE Inventory SET item_name = ?, supplier_name = ?, purchased_price = ?, selling_price = ?, stock_status = ? WHERE item_id = ?";

            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, itemName);
                pstmt.setString(2, supplierName);
                pstmt.setDouble(3, purchasedPrice);
                pstmt.setDouble(4, sellingPrice);
                pstmt.setString(5, stockStatus);
                pstmt.setInt(6, itemId);

                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Item updated successfully.");
                clearFields();
            }
        } catch (NumberFormatException | SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating item. Ensure all fields are correctly filled.");
        }
    }

    private void removeItem() {
        try {
            int itemId = Integer.parseInt(textField_5.getText());

            String sql = "DELETE FROM Inventory WHERE item_id = ?";

            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, itemId);

                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Item removed successfully.");
                clearFields();
            }
        } catch (NumberFormatException | SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error removing item.");
        }
    }

    private void loadItemData(String itemID) {
    	String sql = "SELECT * FROM Inventory WHERE item_id = ?";
        try {
            int itemId = Integer.parseInt(textField_5.getText());
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, itemId);
                ResultSet rs = pstmt.executeQuery();

                if (rs.next()) {
                    textField.setText(rs.getString("item_name"));
                    textField_1.setText(rs.getString("supplier_name"));
                    textField_2.setText(String.valueOf(rs.getDouble("purchased_price")));
                    textField_3.setText(String.valueOf(rs.getDouble("selling_price")));
                    comboBoxStockStatus.setSelectedItem(rs.getString("stock_status"));
                } else {
                    JOptionPane.showMessageDialog(this, "Item ID not found.");
                    clearFields();
                }
            }
        } catch (NumberFormatException | SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading item data.");
        }
    }

    private void clearFields() {
        textField.setText("");
        textField_1.setText("");
        textField_2.setText("");
        textField_3.setText("");
        textField_5.setText("");
        comboBoxStockStatus.setSelectedIndex(0);
    }
}
