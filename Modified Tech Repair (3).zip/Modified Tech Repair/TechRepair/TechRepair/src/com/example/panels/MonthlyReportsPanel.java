package com.example.panels;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MonthlyReportsPanel extends JPanel {
    private JTable table;
    private DefaultTableModel tableModel;

    public MonthlyReportsPanel() {
        setLayout(new BorderLayout());

        // Create the table model
        tableModel = new DefaultTableModel();
        tableModel.addColumn("Report ID");
        tableModel.addColumn("Total Customers");
        tableModel.addColumn("Total Suppliers");
        tableModel.addColumn("Total Items in Inventory");
        tableModel.addColumn("Total Employees");
        tableModel.addColumn("Total Orders");
        tableModel.addColumn("Revenue");
        tableModel.addColumn("Report Date");

        // Create the table
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Create the refresh button
        JButton btnRefresh = new JButton("Refresh");
        btnRefresh.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadReports();
            }
        });
        add(btnRefresh, BorderLayout.SOUTH);

        // Load initial data
        loadReports();
    }

    private void loadReports() {
        // Clear existing data
        tableModel.setRowCount(0);

        // SQL query to fetch reports
        String sql = "SELECT YEAR(CURDATE()) AS report_id, " +
                     "(SELECT COUNT(*) FROM Customers) AS total_customers, " +
                     "(SELECT COUNT(*) FROM Suppliers) AS total_suppliers, " +
                     "(SELECT COUNT(*) FROM Inventory) AS total_items_in_inventory, " +
                     "(SELECT COUNT(*) FROM Employees) AS total_employees, " +
                     "(SELECT COUNT(*) FROM Orders) AS total_orders, " +
                     "(SELECT IFNULL(SUM(total), 0) FROM Orders) AS revenue, " +
                     "CURDATE() AS report_date " +
                     "FROM dual";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            if (rs.next()) {
                // Retrieve data from the result set
                int reportId = rs.getInt("report_id");
                int totalCustomers = rs.getInt("total_customers");
                int totalSuppliers = rs.getInt("total_suppliers");
                int totalItemsInInventory = rs.getInt("total_items_in_inventory");
                int totalEmployees = rs.getInt("total_employees");
                int totalOrders = rs.getInt("total_orders");
                double revenue = rs.getDouble("revenue");
                java.sql.Date reportDate = rs.getDate("report_date");

                // Add row to the table model
                tableModel.addRow(new Object[]{
                        reportId, totalCustomers, totalSuppliers,
                        totalItemsInInventory, totalEmployees, totalOrders,
                        revenue, reportDate
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading reports.");
        }
    }
}
